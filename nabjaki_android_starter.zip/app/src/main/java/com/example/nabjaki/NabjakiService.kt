package com.example.nabjaki

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class NabjakiService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var marker: TextView? = null
    private var attached = false
    private var lastForegroundPackage: String? = null

    // Samsung One UI Home. Other launchers may use a different package name.
    private val launcherPackages = setOf(
        "com.sec.android.app.launcher",
        "com.google.android.apps.nexuslauncher"
    )

    private val checker = object : Runnable {
        override fun run() {
            updateOverlay()
            handler.postDelayed(this, 1200L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, buildNotification())
        if (Settings.canDrawOverlays(this)) createOverlay()
        handler.post(checker)
    }

    private fun createOverlay() {
        if (marker != null) return
        val view = TextView(this).apply {
            text = "납작이 이미지 연결 예정"
            textSize = 13f
            setTextColor(0xFF174A8B.toInt())
            setBackgroundColor(0x00FFFFFF)
            setPadding(12, 12, 12, 12)
        }
        marker = view
    }

    private fun updateOverlay() {
        val view = marker ?: return
        val isHome = isLauncherOnTop()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        if (isHome && !attached && Settings.canDrawOverlays(this)) {
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = 100
            }
            try {
                wm.addView(view, params)
                attached = true
            } catch (_: Exception) { }
        } else if (!isHome && attached) {
            try { wm.removeView(view) } catch (_: Exception) { }
            attached = false
        }
    }

    private fun isLauncherOnTop(): Boolean {
        val usage = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usage.queryEvents(end - 10_000L, end)
        val event = UsageEvents.Event()
        var foregroundPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                (Build.VERSION.SDK_INT >= 29 &&
                 event.eventType == UsageEvents.Event.ACTIVITY_RESUMED)) {
                foregroundPackage = event.packageName
            }
        }
        if (foregroundPackage != null) lastForegroundPackage = foregroundPackage
        return lastForegroundPackage != null && lastForegroundPackage in launcherPackages
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "nabjaki_service",
                "납작이 실행 상태",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = Notification.Builder(this, "nabjaki_service")

        return builder
            .setContentTitle("납작이 실행 중")
            .setContentText("홈 화면에서만 표시 여부를 확인하고 있어요.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int =
        START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(checker)
        if (attached) {
            try {
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                marker?.let { wm.removeView(it) }
            } catch (_: Exception) { }
        }
        attached = false
        marker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
