package com.example.nabjaki

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshStatus()
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }

        val title = TextView(this).apply {
            text = "납작이"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }

        val overlayButton = Button(this).apply {
            text = "1. 다른 앱 위에 표시 허용"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val usageButton = Button(this).apply {
            text = "2. 사용정보 접근 허용"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        val startButton = Button(this).apply {
            text = "권한 확인 후 납작이 켜기"
            setOnClickListener { startIfReady() }
        }

        layout.addView(title)
        layout.addView(status)
        layout.addView(overlayButton)
        layout.addView(usageButton)
        layout.addView(startButton)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val usage = hasUsagePermission()
        status.text = "다른 앱 위에 표시: ${if (overlay) "허용됨" else "허용 필요"}\n" +
                "사용정보 접근: ${if (usage) "허용됨" else "허용 필요"}"
    }

    private fun startIfReady() {
        if (!Settings.canDrawOverlays(this) || !hasUsagePermission()) {
            refreshStatus()
            return
        }
        val intent = Intent(this, NabjakiService::class.java)
        startForegroundService(intent)
        status.text = "납작이 기능이 켜졌어. 홈 화면에서만 표시되도록 감지 중이야."
    }
}
