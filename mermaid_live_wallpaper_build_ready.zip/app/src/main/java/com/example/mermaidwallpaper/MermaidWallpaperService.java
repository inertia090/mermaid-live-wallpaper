package com.example.mermaidwallpaper;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import java.util.Random;

public class MermaidWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new MermaidEngine(); }

    private class MermaidEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private Bitmap mermaid;
        private boolean visible;
        private float x = 0.25f, phase = 0f, speed = 0.0017f;
        private int width = 1, height = 1;
        private long last = 0;
        private final Runnable drawRunner = this::drawFrame;

        MermaidEngine() {
            mermaid = BitmapFactory.decodeResource(getResources(), R.drawable.mermaid);
            setTouchEventsEnabled(false);
        }
        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            width = w; height = h; drawFrame();
        }
        @Override public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) drawFrame(); else handler.removeCallbacks(drawRunner);
        }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false; handler.removeCallbacks(drawRunner);
            super.onSurfaceDestroyed(holder);
        }
        private void drawFrame() {
            handler.removeCallbacks(drawRunner);
            if (!visible || mermaid == null) return;
            long now = System.currentTimeMillis();
            float dt = last == 0 ? 0.016f : Math.min(0.05f, (now-last)/1000f);
            last = now;
            x += speed * dt * 60f;
            if (x > 0.88f) { x = 0.88f; speed = -Math.abs(speed); }
            if (x < 0.12f) { x = 0.12f; speed = Math.abs(speed); }
            phase += dt * 4.2f;

            Canvas c = null;
            try {
                c = getSurfaceHolder().lockCanvas();
                if (c != null) {
                    // Clear to transparent so the phone's selected wallpaper remains visible.
                    c.drawColor(android.graphics.Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR);
                    float maxW = width * 0.34f;
                    float scale = Math.min(maxW / mermaid.getWidth(), (height * 0.43f) / mermaid.getHeight());
                    float dw = mermaid.getWidth() * scale;
                    float dh = mermaid.getHeight() * scale;
                    float bob = (float)Math.sin(phase) * height * 0.012f;
                    float left = x * width - dw/2f;
                    float top = height * 0.72f - dh/2f - Math.abs((float)Math.sin(phase*1.35f))*height*0.045f + bob;
                    c.save();
                    if (speed < 0) {
                        c.scale(-1, 1, left + dw/2f, top + dh/2f);
                    }
                    c.drawBitmap(mermaid, null, new RectF(left, top, left+dw, top+dh), paint);
                    c.restore();
                }
            } finally {
                if (c != null) getSurfaceHolder().unlockCanvasAndPost(c);
            }
            handler.postDelayed(drawRunner, 33);
        }
    }
}
