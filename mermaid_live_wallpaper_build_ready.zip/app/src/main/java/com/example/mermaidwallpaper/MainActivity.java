package com.example.mermaidwallpaper;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(Color.rgb(235, 246, 248));
        TextView title = new TextView(this);
        title.setText("인어 통통 배경화면");
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(35, 74, 83));
        TextView hint = new TextView(this);
        hint.setText(getString(R.string.open_hint));
        hint.setTextSize(16);
        hint.setTextColor(Color.DKGRAY);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 24, 0, 24);
        Button button = new Button(this);
        button.setText(getString(R.string.apply_wallpaper));
        button.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, MermaidWallpaperService.class));
            startActivity(intent);
        });
        layout.addView(title);
        layout.addView(hint);
        layout.addView(button);
        setContentView(layout);
    }
}
