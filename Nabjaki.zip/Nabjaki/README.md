# 납작이

Android 앱 프로젝트입니다.

## 빌드
- JDK 17
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- `gradle assembleDebug`

## 현재 구현 범위
- 다른 앱 위에 표시 권한 안내
- 사용정보 접근 권한 안내
- 홈 화면 여부를 사용정보 이벤트로 확인
- 홈 화면일 때 임시 텍스트 오버레이 표시

## 아직 검증이 필요한 점
- Samsung One UI Home에서 홈 화면 판별이 정확한지
- Android 14/15/16 계열의 specialUse foreground service 동작 및 정책 적합성
- 실제 기기에서 권한 및 오버레이 동작
- 납작이 원본 이미지 연결

이 프로젝트는 아직 실제 기기에서 빌드·실행 검증을 완료하지 않았습니다.
